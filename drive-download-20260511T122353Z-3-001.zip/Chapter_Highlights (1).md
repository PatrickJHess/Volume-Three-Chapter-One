# Chapter Highlights

**Chapter One: A First Look at the Term Structure of Interest Rates**.

Chapter One introduces the foundational principles of bond pricing. A primary focus of this chapter is calculating the term structure of interest rates, an essential gauge of financial market health, using data from US Treasury Bills (T-bills).


**Highlights of the chapter are:**

* ***Financial concepts***

    * *Basic bond pricing*
    * *Defining the term structure of interest rates*
    * *Calculating and graphing the term structure of interest rates*
    * *The term structure and the state of financial markets*

* ***Python concepts***

    * *NumPy arrays*
    * *Pandas DataFrames*
    * *Accessing data with a URL address*
    * *Custom modules*
## Background

This chapter's examples and discussions rely on the **Pandas** and **NumPy** libraries.

* **Pandas** is introduced in [*A Quick Introduction to Pandas*](https://patrickjhess.github.io/Introduction-To-Python-For-Financial-Python/An_Introduction_To_Pandas.html#a-quick-introduction-to-pandas).  
* **NumPy** is introduced in [*A Quick Introduction to NumPy*](https://patrickjhess.github.io/Introduction-To-Python-For-Financial-Python/An_Introduction_To_NumPy.html#a-quick-introduction-to-numpy).  
* The *NumPy and Pandas* notebook in this chapter provides examples of using these libraries in relation to the *Calculating and Graphing the Term Structure of Interest Rates* notebook.  
* Additional relevant Python concepts can be found in the introductory volume, [*Background Material: An Introduction to Python for Financial Python*](https://patrickjhess.github.io/Introduction-To-Python-For-Financial-Python/intro.html), that relate to this and other chapters of *Basic Concepts of Fixed Income*.

**The chapter includes five sections:**

1. *Bond Pricing* covers some  basic concepts. 
2. The  Jupyter notebook *NumPy and Pandas* introduces and illustrates the modules. 
3. The  Jupyter notebook *Calculating and Graphing the Term Structure* uses NumPy and Pandas to:
   * download data from DropBox that is used to calculate and graph the term structure on September 15, 2022.
   * download data from the U.S. Treasury that is used to calculate and graph the term structure on September 30, 2025
   * an exercise asking you to calculate and plot spot and forward rates with data downloaded from the US Treasury.
4. *Chapter Summary* summarizes the financial concepts and results.
5. *Imported Functions* describes the functions imported from DropBox (*module_basic_concepts_fixed_income*).








